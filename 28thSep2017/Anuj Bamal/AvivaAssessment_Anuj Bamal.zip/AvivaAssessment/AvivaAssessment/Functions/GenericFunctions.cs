﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using AvivaAssessment.PageObjects;
using NUnit.Framework;

namespace AvivaAssessment.Functions
{
    class GenericFunctions
    {
        public static IWebDriver driver;
        SearchResultPage SRP;
        public void OpenBrowser(string strBrowser)
        {
            if (strBrowser.ToUpper()== "CHROME")
            {
                driver = new ChromeDriver();
            }
            else if (strBrowser.ToUpper() == "IE")
            {
                driver = new InternetExplorerDriver();
            }
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(2000);
        }

        public void NavigateToURL(string URL)
        {
            driver.Navigate().GoToUrl(URL);
        }

        public int GetNumberOfLinkOnAPage()
        {
            SRP = new SearchResultPage(driver);
            int noOfLinks = SRP.GetNumberOfLinksOnPage();
            return noOfLinks;
        }

        public Boolean VerifyNumberOfLinks(int expectedNoOfLinks)
        {
            int noOfLinks = GetNumberOfLinkOnAPage();
            if (noOfLinks== expectedNoOfLinks)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetTextOfLink(int indexOfLink)
        {
            IList<IWebElement> links = driver.FindElements(By.TagName("h3"));
            string linkText = links.ElementAt(indexOfLink).FindElement(By.TagName("a")).Text;
            return linkText;
        }

        public static void CloseAllBrowsers()
        {
            driver.Quit();
        }

    }
}
