﻿using System;
using TechTalk.SpecFlow;
using AvivaAssessment.Functions;
using AvivaAssessment.PageObjects;
using NUnit.Framework;

namespace AvivaAssessment.FeaturesSteps
{
    [Binding]
    public class VerifyNumberOfLinksSteps
    {
        GenericFunctions GF = new GenericFunctions();
        GoogleHomePage GHP;        
        [Given]
        public void GivenIHaveOpenedGoogleHomePage()
        {
            GF.OpenBrowser("Chrome");
            GF.NavigateToURL("https://www.google.com");
        }
        
        [Given]
        public void GivenIHaveEnter_P0_InSearchTextBox(string p0)
        {
            GHP = new GoogleHomePage(GenericFunctions.driver);
            GHP.EnterValueInSearchTextBox(p0);
        }
        
        [When]
        public void WhenIPressGoogleSearchButton()
        {
            GHP = new GoogleHomePage(GenericFunctions.driver);
            GHP.ClickOnSearchButton();
        }
        
        [Then]
        public void ThenTheResultPageShouldReturn_P0_Links(int numberOfLinks)
        {
            int noOfLinks = GF.GetNumberOfLinkOnAPage();
            Console.WriteLine("Number Of Links present on the 1st search results page are " + noOfLinks);
            Assert.AreEqual(numberOfLinks, noOfLinks);
        }
        
        [Then]
        public void ThenTheResultPageShouldNotReturn_P0_Links(int numberOfLinks)
        {
            int noOfLinks = GF.GetNumberOfLinkOnAPage();
            Console.WriteLine("Number Of Links present on the 1st search results page are "+ noOfLinks);
            Assert.AreNotEqual(numberOfLinks, noOfLinks);
        }

        [Then(@"Get the link text of (.*)th link")]
        public void ThenGetTheLinkTextOfThLink(int indexOfLink)
        {
            Console.WriteLine("Link text of "+ indexOfLink + "th link is "+GF.GetTextOfLink(indexOfLink-1));
        }
                        
        [AfterScenario]
        public static void closeAllBrowsers()
        {
            GenericFunctions.CloseAllBrowsers();
        }
    }
}
