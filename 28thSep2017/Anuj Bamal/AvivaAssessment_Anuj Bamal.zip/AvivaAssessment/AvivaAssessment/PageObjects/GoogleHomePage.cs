﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace AvivaAssessment.PageObjects
{
    class GoogleHomePage
    {
        IWebDriver driver;
        public GoogleHomePage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How =How.Id,Using = "lst-ib")]
        public IWebElement searchTxtBox { set; get; }

        [FindsBy(How =How.Name,Using = "btnK")]
        public IWebElement searchButton { set; get; }

        public void EnterValueInSearchTextBox(string value)
        {
            searchTxtBox.SendKeys(value);
        }

        public void ClickOnSearchButton()
        {
            //searchButton.Click();
            searchTxtBox.Submit();
        }

    }
}
