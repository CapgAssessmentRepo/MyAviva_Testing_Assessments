﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace AvivaAssessment.PageObjects
{
    class SearchResultPage
    {
        IWebDriver driver;
        public SearchResultPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        public int GetNumberOfLinksOnPage()
        {
            IList<IWebElement> links = driver.FindElements(By.TagName("h3"));
            return links.Count;
        }

        
    }
}
