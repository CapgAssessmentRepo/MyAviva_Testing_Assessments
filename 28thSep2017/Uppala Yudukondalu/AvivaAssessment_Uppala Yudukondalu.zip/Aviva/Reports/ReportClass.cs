﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Reports
{
    public class ReportClass
    {
        public static ExtentReports Extent;
        public static ExtentTest Test;
        public static ExtentHtmlReporter HtmlReporter;
        
        public static void  StartReport()
        {
            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));
            string projectPath = new Uri(actualPath).LocalPath;
            string reportPath = projectPath + "\\HTMLReports\\GoogleSearchAvivaReport.html";
            HtmlReporter = new ExtentHtmlReporter(reportPath);
            HtmlReporter.Configuration().ReportName = "Searching Aviva in Google Serach";
            //HtmlReporter.Configuration().Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            Extent = new ExtentReports();
            Extent.AttachReporter(HtmlReporter);


        } 
    }
}
