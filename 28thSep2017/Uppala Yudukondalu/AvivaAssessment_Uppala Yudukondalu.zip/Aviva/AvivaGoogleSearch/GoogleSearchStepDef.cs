﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Reports;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using FunctionLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AvivaGoogleSearch
{
    [Binding]
    public sealed class GoogleSearchStepDef
    {
        GoogleFunctions Funcs = new GoogleFunctions();
        [BeforeTestRun]
        public static void InitializeReport()
        {
            ReportClass.StartReport();
        }
        [AfterTestRun]
        public static void EndReport()
        {
            ReportClass.Extent.Flush();
        }
        [BeforeScenario]
        public static void StartTestReportForScenario()
        {
            var scenarioTags = ScenarioContext.Current.ScenarioInfo.Tags;
            ReportClass.Test = ReportClass.Extent.CreateTest(scenarioTags[0]);
            
        }
        [AfterScenario]
        public static void CloseOpenedBrowser()
        {
            GoogleFunctions.CloseBrowser();
        }
        
        [Given]
        public void GivenIHaveOpenedChromeBrowser()
        {
            Funcs.InvokeDriver();
            Funcs.MaximizeBrowser();
        }


        [Given]
        public void GivenIHaveNavigatedToGoogleHomePage()
        {
            Funcs.OpenURL();
            ReportClass.Test.Pass("Google URL is opened");
            
        }

                
        [When(@"I have entered Aviva in Google search")]
        public void WhenIHaveEnteredAvivaInGoogleSearch()
        {
            Funcs.EnterTextInGoogle("Aviva");
            ReportClass.Test.Pass("The text Aviva is entered in Google search");
        }


        [When]
        public void WhenIClickOnSearchButton()
        {
            Funcs.ClickOnSearchButton();
            ReportClass.Test.Pass("Clicked on Google search button");
        }

        
        [Then(@"The resulted links should be (.*)")]
        public void ThenTheResultedLinksShouldBe(int LinksCount)
        {
            int ExpectedLinks = LinksCount;
            int ActualLinks = Funcs.NoOfLinksResulted();

            try
            {
                if (ExpectedLinks> ActualLinks)
                {
                    Assert.IsTrue((ExpectedLinks - ActualLinks >= 20) || (ExpectedLinks - ActualLinks <= 20));
                    ReportClass.Test.Pass("Links resulted after searching with Aviva are matching with expected count: Links count is " + ActualLinks);
                }
                else
                {
                    Assert.IsTrue((ActualLinks - ExpectedLinks >= 20) || (ActualLinks - ExpectedLinks <= 20));
                    ReportClass.Test.Pass("Links resulted after searching with Aviva are matching with expected count: Links count is " + ActualLinks);
                }
                
            }
            catch
            {
                ReportClass.Test.Fail("Links resulted after searching with Aviva are not matching with expected count: Links count is " + ActualLinks);
            }

        }


        [Then(@"Prith the (.*) in Report")]
        public void ThenPrithTheInReport(int LinkNum)
        {
            string LinkName = Funcs.GetLinkName(LinkNum);
            ReportClass.Test.Pass("The " + LinkNum + "th link is " + LinkName);
        }



        [Given]
        public void GivenIHaveEnteredDummyTextInGoogleSearch()
        {
            Funcs.EnterTextInGoogle("DummyText");
            ReportClass.Test.Pass("The text DummyText is entered in Google search");
        }

        [Then]
        public void ThenTheResultedLinksAreNotSameAsAviva()
        {
            int DummyLinks = Funcs.NoOfLinksResulted();
            Funcs.EnterTextInGoogle("Aviva");
            Funcs.ClickSearchInSerachResults();
            int AvivaLinks = Funcs.NoOfLinksResulted();
            try
            {
                Assert.IsFalse(DummyLinks == AvivaLinks);
                ReportClass.Test.Pass("The links resulted with dummy data are not matched with Aviva links count ;   Aviva search links count is "+ AvivaLinks+" DummyText search links count is  "+ DummyLinks);
            }
            catch
            {
                ReportClass.Test.Fail("The links resulted with dummy data are matched with Aviva links count ;   Aviva search links count is  " + AvivaLinks + " DummyText search links count is " + DummyLinks);
            }

        }

    }
}
