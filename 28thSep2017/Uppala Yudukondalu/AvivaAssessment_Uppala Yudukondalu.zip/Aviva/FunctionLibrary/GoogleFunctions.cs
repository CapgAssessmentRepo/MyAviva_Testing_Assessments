﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using ObjectRepository;

namespace FunctionLibrary
{
    public class GoogleFunctions
    {
        public static IWebDriver driver;
        public GoogleObjects OR;

        //This function is to invoke the driver
        public void InvokeDriver()
        {
            driver = new ChromeDriver();
            OR = new GoogleObjects(driver);
        }

        //This function is to open the Google url
        public void OpenURL()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
        }

        //This functions is to enter text in Google search box
        public void EnterTextInGoogle(string searchword)
        {
            OR.GoogleSearchBox.Clear();
            OR.GoogleSearchBox.SendKeys (searchword);
        }

        //To click on Search button on Google search page
        public void ClickOnSearchButton()
        {
            OR.GoogleSearchButton.Click();
        }
        //To Maximize the browser
        public void MaximizeBrowser()
        {
            driver.Manage().Window.Maximize();
        }

        public int NoOfLinksResulted()
        {
            IList<IWebElement> AvivaLinks = driver.FindElements(By.TagName("a"));
            return AvivaLinks.Count;
        }
        public String GetLinkName(int pos)
        {
            IList<IWebElement> AvivaLinks = driver.FindElements(By.TagName("a"));
            return AvivaLinks.ElementAt<IWebElement>(pos - 1).GetAttribute("text");
        }
        public void ClickSearchInSerachResults()
        {
            OR.GoogleSearchButtonInResults.Click();
        }
        public static void CloseBrowser()
        {
            driver.Close();
        }


    }
}
