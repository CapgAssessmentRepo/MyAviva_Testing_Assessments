﻿using System;
using TechTalk.SpecFlow;
using AvivaTest.UtilityScripts;
using AvivaTest.Pages;
using NUnit.Framework;

namespace AvivaTest.TestFeatureSteps
{
    [Binding]
    public class AvivaTestSteps:BaseTest
    {
        GoogleHomePage googleHomePage;
        SearchResultsPage searchResultspage;
        ScreenShots st;
        [BeforeScenario]
        public void Setup()
        {
            initializeDriver("Chrome");
            googleHomePage = new GoogleHomePage();
            searchResultspage = new Pages.SearchResultsPage();
            st = new ScreenShots();
        }
        
        [Given(@"Launch GoogleHome Page")]
        public void GivenLaunchGoogleHomePage()
        {
            googleHomePage.NavigateToURL("https://google.com");
        }
        
        [Given(@"Search With Text ""(.*)""")]
        public void GivenSearchWithText(string p0)
        {
            googleHomePage.searchWithText(p0);
        }
        
        [When(@"click on Search Button")]
        public void WhenClickOnSearchButton()
        {
            googleHomePage.ClickonSearch();
        }


        [Then(@"User verifies and prints the number of search results returned")]
        public void ThenUserVerifiesAndPrintsTheNumberOfSearchResultsReturned()
        {
            int searResults = searchResultspage.getLinksCount();
            Console.WriteLine("Aviva Google SearchResults: " + searResults);
            Assert.AreEqual(searchResultspage.getLinksCount(), 9);
        }

        [Then(@"User prints the link text of (.*)th link")]
        public void ThenUserPrintsTheLinkTextOfThLink(int p0)
        {
            string fifthText = searchResultspage.LinkText(5);
            Console.WriteLine("Fifth Link Text: " + fifthText);

        }


        [Then(@"verify the Browser title ""(.*)""")]
        public void ThenVerifyTheBrowserTitle(string p0)
        {
            string title = DrTitle();
            Assert.AreEqual(title, p0);
        }



        [Then(@"I should verify the links count from Aviva google Search Results")]
        public void ThenIShouldVerifyTheLinksCountFromAvivaGoogleSearchResults()
        {
            Assert.AreEqual(searchResultspage.getLinksCount(),6);
        }

        [AfterScenario]
        public void TearDown()
        {
            CloseBrowser();
        }
        [AfterStep()]
        public void TakeScreenshots()
        {
            st.TakeScreenshot();
        }
    }
}
