﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SampleTest.StepDef
{
    class PageObjectTest
    {

        public PageObjectTest()
        {
            PageFactory.InitElements(BaseDriver.driver, this);
        }

        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement SearchBox { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement GoogleSearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@value='Google Search']")]
        public IWebElement Google_Search { get; set; }

        [FindsBy(How = How.Id, Using = "resultStats")]
        public IWebElement ResultsString { get; set; }



        public int NumberOfLinks(string Keyword)
        {
            IList<IWebElement> Ls = BaseDriver.driver.FindElements(By.XPath("//a[contains(text(),'" + Keyword + "')]"));

            return Ls.Count;
        }

        public int NumberOfLinks()
        {
            IList<IWebElement> Ls = BaseDriver.driver.FindElements(By.XPath("//a[contains(text(),'Aviva')]"));

            return Ls.Count;
        }


        public String NumberOfLinks(int indx)
        {
            IList<IWebElement> Ls = BaseDriver.driver.FindElements(By.XPath("//a[contains(text(),'Aviva')]"));

             String LinkText= Ls.ElementAt(indx).Text;
            return LinkText;
        }

        public void ScreenCapture()
        {
            ITakesScreenshot takesScreenshot = (ITakesScreenshot)BaseDriver.driver;
            if (takesScreenshot != null)
            {
                var screenshot = takesScreenshot.GetScreenshot();
                var tempFileName = Path.Combine(Directory.GetCurrentDirectory(), Path.GetFileNameWithoutExtension(Path.GetTempFileName())) + ".jpg";
                screenshot.SaveAsFile(tempFileName, ScreenshotImageFormat.Jpeg);

                Console.WriteLine($"SCREENSHOT[ file:///{tempFileName} ]SCREENSHOT");
            }
        }



        public void CustomeWait()
        {
            Thread.Sleep(2000);
        }



    }
}
