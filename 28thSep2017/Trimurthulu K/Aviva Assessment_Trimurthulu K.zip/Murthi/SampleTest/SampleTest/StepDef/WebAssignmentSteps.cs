﻿using NUnit.Framework;
using System;
using System.Threading;
using TechTalk.SpecFlow;

namespace SampleTest.StepDef
{
    [Binding]
    public class CheckNumberOfLinksReturnedOnTheSerachResultsPageSteps:BaseDriver
    {

        PageObjectTest page;
        [BeforeScenario]
        public void DriverInit()
        {
            initializeDriver();
            page = new PageObjectTest();
        }


        [Given(@"User is on Google Page")]
        public void GivenUserIsOnGooglePage()
        {
           
            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            NavigateToURL("https://google.co.in");


       
        }
        
        [When(@"User enters Search Keyword '(.*)'")]
        public void WhenUserEntersSearchKeyword(string SearchKeyword)
        {

            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            page.CustomeWait();
            page.SearchBox.Clear();
            page.SearchBox.SendKeys(SearchKeyword);

           
        }
        
        [When(@"User choose Search Button")]
        public void WhenUserChooseSearchButton()
        {

            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            page.GoogleSearch.Click();

           
        }
        
        [When(@"User enters '(.*)' in Search input box")]
        public void WhenUserEntersInSearchInputBox(string p0)
        {
            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            page.SearchBox.Clear();
            page.SearchBox.SendKeys(p0);

           
        }

        [Then(@"Find the number of links and link text of (.*)")]
        public void ThenFindTheNumberOfLinksAndLinkTextOf(int p0)
        {


            page.CustomeWait();
            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            Console.WriteLine("Number of Links for Aviva Keyword  :" + page.NumberOfLinks());
            Console.WriteLine("Text of the Link 5  =>  " + page.NumberOfLinks(p0-1));

        }


        [Then(@"It should  show (.*) for  '(.*)'")]
        public void ThenItShouldShowFor(int p0, string p1)
        {

            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            page.CustomeWait();
            Assert.AreEqual(p0, page.NumberOfLinks(p1));
            
        }

        [AfterScenario]
        public void CloseInstance() {

            Console.WriteLine("Close Browser and Driver Instance");
            page.CustomeWait();
            Browserclose();


        }

        [AfterStep]
        public void ImageCapture()
        {

            page.ScreenCapture();


        }


    }
}
