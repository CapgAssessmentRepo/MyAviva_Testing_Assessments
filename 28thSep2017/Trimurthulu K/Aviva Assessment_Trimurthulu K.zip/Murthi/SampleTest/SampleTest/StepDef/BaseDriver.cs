﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SampleTest.StepDef
{
    public class BaseDriver
    {
        public static IWebDriver driver;

        public void initializeDriver()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
        }

        public void NavigateToURL(string sURL)
        {
            driver.Navigate().GoToUrl(sURL);
        }



      

        public void Browserclose()
        {

           

            driver.Close();
            driver.Quit();

        }



    }
}
