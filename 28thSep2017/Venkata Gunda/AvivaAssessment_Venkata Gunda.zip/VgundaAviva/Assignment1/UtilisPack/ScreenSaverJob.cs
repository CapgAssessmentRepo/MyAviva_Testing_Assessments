﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.UtilisPack
{
    class ScreenSaverJob
    {
        //this method will be used to save the browser screenshot
        //this method required driver & file path as the parameters
        public void TakeScreen(IWebDriver _driver,string _filePath)
        {
            //defining the name of the image
            string _title = _filePath + DateTime.Now.ToString("ddMMMyyyy_HH'H'_mm'M'_ss'Sec'") + ".png";


            var _screenShot = ((ITakesScreenshot)_driver).GetScreenshot();

            //using the byte converter to avoid the runtime exceptions..
            byte[] _imageBytes = Convert.FromBase64String(_screenShot.ToString());

            using (BinaryWriter bw = new BinaryWriter(new FileStream(_title, FileMode.Append, FileAccess.Write)))
            {
                bw.Write(_imageBytes);
                bw.Close();
            }

            //log the location of the image file
            Console.WriteLine("Screenshot saved @ {0}", _title);

        }
    }
}
