﻿using Assignment1.UtilisPack;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Pages
{
    class ResultsPage
    {
        //define the local driver
        private IWebDriver _driver;

        //create the object for ScreenSaverJob to use the TakeScreen method
        ScreenSaverJob _takeScreen = new ScreenSaverJob();

        //locate the required elements
        [FindsBy(How = How.TagName, Using = "a")]
        [CacheLookup]
        public IList<IWebElement> _allLinks { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='med card-section']/p[1]")]
        [CacheLookup]
        public IWebElement _noLinksText { get; set; }

        //initilization of the elements in the page
        public ResultsPage(IWebDriver driver)
        {
            this._driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        //this method will count the links in the web page
        public void CountLinks()
        {
            int linkCount = 0;

            //this loop will count the number of links having the keyword in the link text
            foreach (IWebElement iLink in _allLinks)
                {
                    if (iLink.Text.IndexOf(SearchFunctionSteps._keyWord, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        linkCount++;
                        //print the link text if the link is at 5th position
                        if (linkCount == SearchFunctionSteps._nThLink)
                        {
                            Assert.That(iLink.Text, Is.Not.Null, "link text is null for {0} element", SearchFunctionSteps._nThLink);
                            Console.WriteLine("Link text present in '{0}' item is ***{1}***", SearchFunctionSteps._nThLink, iLink.Text);
                        }

                    }
                }
          
            //checking the total links are greterthan the requried number
            Assert.IsTrue(linkCount > SearchFunctionSteps._nThLink,"***Total links are lessthan the required***");

            //log with execution status information
            Console.WriteLine("Total Links in the results page are {0}", _allLinks.Count);
            Console.WriteLine("Total Links having the '{0}' keyword are {1} (with case insensitive)", SearchFunctionSteps._keyWord, linkCount);
        }

        //this method will be used for zero links scenario
        public void zerolinks()
        {
            //verifying if we got any results.
            foreach (IWebElement iLink in _allLinks)
            {
                if (iLink.Text.IndexOf(SearchFunctionSteps._keyWord, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    //fail the scenario and throw below message
                    Assert.Fail("***Search results are greater than 1***");
                }
            }

            //take the screenshot
            _takeScreen.TakeScreen(_driver, SearchFunctionSteps._filePath);
        }

        public void NoMatchingLinksMessage()
        {

            Console.WriteLine("Message in Browser '{0}'",_noLinksText.Text);
            //verifying the Nolinks text is matching or not
            Assert.IsTrue(_noLinksText.Text == "Your search - "+ SearchFunctionSteps._keyWord+ " - did not match any documents.");


        }

    }
}
