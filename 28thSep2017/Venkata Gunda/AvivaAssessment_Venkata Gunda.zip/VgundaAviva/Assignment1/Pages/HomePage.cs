﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Pages
{
    class HomePage
    {
        //define the local driver
        private IWebDriver _driver;

        //locate the required elements
        [FindsBy(How = How.Name, Using = "q")]
        [CacheLookup]
        public IWebElement _searchBox { get; set; }
        
        //initilization of the elements in the page
        public HomePage(IWebDriver driver)
        {
            this._driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        //Actions defined / required in the Home page
        public void searchOperation(string keyword)
        {
            _searchBox.SendKeys(keyword);
            _searchBox.Submit();
        }

    }
}
