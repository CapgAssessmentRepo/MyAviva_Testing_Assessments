﻿using Assignment1.Pages;
using Assignment1.UtilisPack;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace Assignment1
{
    [Binding]
    public class SearchFunctionSteps
    {
        //declare a driver
        IWebDriver _driver = new ChromeDriver();
        
        //creating the static variable to use in other classes (if needed)
        public static string _keyWord;
        public static int _nThLink;
        public static string _filePath = "../TestResults\\";

        //create the object for ScreenSaverJob to use the TakeScreen method
        ScreenSaverJob _takeScreen = new ScreenSaverJob();

        [Given]
        public void GivenIHaveOpenedTheWebBrowser()
        {
            //This method will use the driver which is defined in this class and navigate to search engine i.e. Google.com
            _driver.Url = "http:\\www.google.com";
            _driver.Manage().Timeouts().ImplicitWait= TimeSpan.FromSeconds(5);
            _driver.Manage().Window.Maximize();
        }
        
        [When]
        public void WhenIHaveEntered_P0_KeywordToSearch(string Keyword)
        {
            //save the keyword into static variable
            _keyWord = Keyword;

            //create the Homepage object and use the search operation method
            var _HomePage = new HomePage(_driver);
            _HomePage.searchOperation(Keyword);
        }

        [Then]
        public void ThenWebResultsWillBeLoadedAlongWithWorkingHyperlinks()
        {
            //take the screenshot of the web browser with searcg results and save the file
            _takeScreen.TakeScreen(_driver, _filePath);
        }
        
        [Then]
        public void ThenIWillBeAbleToVerify_P0_LinkTextInWebResults(int NthLink)
        {
            //save the nTh link into the static variable
            _nThLink = NthLink;

            //create the Resultspage object and use the Countlinks method
            var _resultsPage = new ResultsPage(_driver);
            _resultsPage.CountLinks();

            //Quit all the browser
            _driver.Quit();
        }

        [Then]
        public void ThenNoURLsAreDisplayedFor_P0(string p0)
        {
            //this block will be executed when no links are displayed
            var _resultsPage = new ResultsPage(_driver);
            _resultsPage.zerolinks();
        }

        [Then]
        public void ThenResultsWebpageWillBeLoadedWithProperTextMessaage()
        {
            //this block will be verify the text message displayed for NO matching links
            var _resultsPage = new ResultsPage(_driver);
            _resultsPage.NoMatchingLinksMessage();

            //Quit all the browser
            _driver.Quit();
        }


    }
}
