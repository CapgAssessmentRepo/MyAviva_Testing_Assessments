﻿using AVIVA_Assignment.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;


namespace AVIVA_Assignment
{
    [Binding]
    public class SearchTheKeywordInGoogleSteps
    {
        private IWebDriver driver;

        [Given(@"Launch the chrome browser using ""(.*)""")]
        public void GivenLaunchTheChromeBrowserUsing(string URL)
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            GoogleSearchPage obj = new PageObjects.GoogleSearchPage(driver);
                obj.goToGooglepage(URL);

        }
        
        [Given(@"Enter ""(.*)"" in search box")]
        public void GivenEnterInSearchBox(string Keyword)
        {
            GoogleSearchPage Mysearch = new PageObjects.GoogleSearchPage(driver);
            Mysearch.SearchText(Keyword);
        }
        
        [When(@"I press search button")]
        public void WhenIPressSearchButton()
        {
            GoogleSearchPage btn = new PageObjects.GoogleSearchPage(driver);
            btn.ClickSearch();
        }

        [Then(@"Total links (.*) should be displayed on results page\.")]
        public void ThenTotalLinksShouldBeDisplayedOnResultsPage_(int LinksCount)
        {
            ResultsPage Results = new PageObjects.ResultsPage(driver);
            Results.ResultLinkCount(LinksCount);
            
        }
        [Then(@"link (.*) text should be ""(.*)"" displayed in results\.")]
        public void ThenLinkTextShouldBeDisplayedInResults_(int linktext, string ExpText)
        {
            ResultsPage LinkValue = new PageObjects.ResultsPage(driver);
            LinkValue.PrintLinkText(linktext, ExpText);
            driver.Close();

        }
        [Then(@"Total links (.*) should not be displayed on results page\.")]
        public void ThenTotalLinksShouldNotBeDisplayedOnResultsPage_(int Links)
        {
            ResultsPage nLink = new ResultsPage(driver);
            nLink.LinkCount(Links);
            driver.Close();

        }


    }
}



