﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVIVA_Assignment.PageObjects
{
    class ResultsPage
    {
        private IWebDriver Driver;

        public ResultsPage(IWebDriver Driver)
        {
            this.Driver = Driver;
            PageFactory.InitElements(Driver, this);

        }

        //[FindsBy(How = How.TagName, Using = "a")]
        //public IList<IWebElement> resultLinks { get; set; }
        [FindsBy(How = How.XPath, Using = "//h3//a")]
        public IList<IWebElement> resultLinks;
        
        public void ResultLinkCount(int ExpectedCount)
        {
            Console.WriteLine("Actual value : " + resultLinks.Count + " Expected Value: " + ExpectedCount);
            Assert.AreEqual(ExpectedCount, resultLinks.Count);
        }
        public void PrintLinkText(int linktext, String ExpText)
        {
            
            for (int i = 0; i <= resultLinks.Count; i++)
            {
                if (i == (linktext - 1))
                {
                    string LinkVal = resultLinks.ElementAt(i).Text;
                    Console.WriteLine("Text of link " + linktext + " is: " + LinkVal);
                    Assert.AreEqual(ExpText, LinkVal);
                    break;
                }
            }

        }

        public void LinkCount(int Links)
        {
            Console.WriteLine("First page search results total links are less than :" + Links);
            Assert.AreNotEqual(Links, resultLinks.Count);
        }
    }
}
