﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVIVA_Assignment.PageObjects
{
    class GoogleSearchPage
    {
        private IWebDriver driver;

        public GoogleSearchPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        [FindsBy(How = How.Name, Using = "q")]
        private IWebElement searchBox{ get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        private IWebElement searchButton{ get; set; }

        public void goToGooglepage(String URL)
        {
            driver.Navigate().GoToUrl(URL);

        }
        public ResultsPage SearchText(String Keyword)
        {
            searchBox.SendKeys(Keyword);

            return new ResultsPage(driver);
        }
        public void ClickSearch()
        {
            searchButton.Click();
        }
    }
}
