﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.IO;

namespace Aviva_Assessment.Utility
{
     public class BaseDriver
    {
        public static IWebDriver driver;

        public void initializeDriver()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
            Console.WriteLine("Chrome Driver Initiated and Lanuched Browser");

        }

        public void NavigateToURL(string AppURL)
        {
            driver.Navigate().GoToUrl(AppURL);
            Console.WriteLine("Application Navigated to" + AppURL);

        }
       
        public void WaitForElement(IWebDriver driver, By locator, int timeOut)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromMinutes(timeOut));

            IWebElement element = wait.Until<IWebElement>(ExpectedConditions.ElementIsVisible(locator));
        }
        
        public void WaitForElementInvsible(IWebDriver driver, By locator, int timeOut)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromMinutes(timeOut));

            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(locator));
        }


        public static IWebElement DefaultWait(IWebDriver driver, By locator, int timeOut)
        {
            DefaultWait<IWebDriver> wait = new DefaultWait<IWebDriver>(driver);
            wait.Timeout = TimeSpan.FromMinutes(timeOut);
            wait.PollingInterval = TimeSpan.FromMilliseconds(150);
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException));


            IWebElement element = wait.Until((dr) =>
            {
                return dr.FindElement(locator);
            });

            return element;

        }
        public void TakeScreenshot()
        {
            ITakesScreenshot takesScreenshot = (ITakesScreenshot)driver;
            if (takesScreenshot != null)
            {
                var screenshot = takesScreenshot.GetScreenshot();
                var tempFileName = Path.Combine(Directory.GetCurrentDirectory(), Path.GetFileNameWithoutExtension(Path.GetTempFileName())) + ".jpg";
                screenshot.SaveAsFile(tempFileName, ScreenshotImageFormat.Jpeg);
                Console.WriteLine($"SCREENSHOT[ file:///{tempFileName} ]SCREENSHOT");
            }
        }

        public void CloseBrowser()
        {

            driver.Close();
            driver.Quit();
            Console.WriteLine("All the Browser Instance are completed");

        }
     
    }
}
