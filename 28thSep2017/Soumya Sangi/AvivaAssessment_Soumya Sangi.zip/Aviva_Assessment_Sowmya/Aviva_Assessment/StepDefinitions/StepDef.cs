﻿using Aviva_Assessment.ObjectRepository;
using Aviva_Assessment.Utility;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Aviva_Assessment.StepDefinitions
{
    [Binding]
    public class StepDef : BaseDriver
    { 

    OR page;
    
        [BeforeScenario]
        public void DriverInit()
        {
            initializeDriver();
            page = new OR();
        }
        [Given(@"User is on Google Home Page")]
        public void GivenUserIsOnGoogleHomePage()
        {
            Console.WriteLine("Navigate to Application URL");
            NavigateToURL("https://google.co.in");
           
        }
        
        [When(@"User inputs search Keyword in search text box")]
        public void WhenUserInputsSearchKeywordInSearchTextBox(Table table)
        {
            dynamic Keyword = table.CreateDynamicInstance();
            page.enterText(Keyword.SearchKeyword);
            Console.WriteLine("Entered the value successfully");
        }

        [When(@"Click on Search Button")]
        public void WhenClickOnSearchButton()
        {
            page.click();
        }
        
        [When(@"User inputs search Keyword as '(.*)' in search text box")]
        public void WhenUserInputsSearchKeywordAsInSearchTextBox(string p0)
        {
            page.enterText(p0);
        }
        
        [Then(@"It should display links related to '(.*)' Keyword")]
        public void ThenItShouldDisplayLinksRelatedToKeyword(string p0)
        {
            DefaultWait(driver, By.TagName("a"), 10);

            int NoOfLinks= page.NumberOfLinks(p0);
            Console.WriteLine("Links Count :: " + NoOfLinks);
        }
        
        [Then(@"It should display (.*) related to '(.*)'")]
        public void ThenItShouldDisplayRelatedTo(int p0, string p1)
        {
            int NoOfLinks = page.NumberOfLinks(p1);
            Assert.AreEqual(NoOfLinks, p0);
            //string linktext= page.LinkText(p1);
            //Console.WriteLine(linktext);
        }
        [Then(@"It should print (.*)th link text value related to '(.*)' keyword")]
        public void ThenItShouldPrintThLinkTextValueRelatedToKeyword(int p0, string p1)
             {

            DefaultWait(driver, By.TagName("a"), 10);
            int NoOfLinks = page.NumberOfLinks(p1);
            Console.WriteLine("Links Count :: " + NoOfLinks);
            string linktext = page.LinkText(p1,p0);
            Console.WriteLine(linktext);
        }
        
        [AfterScenario]
        public void CloseInstance()
        {
            CloseBrowser();
        }
        [AfterStep()]
        public void TakeScreenshots()
        {
           TakeScreenshot();
        }
    }
}
