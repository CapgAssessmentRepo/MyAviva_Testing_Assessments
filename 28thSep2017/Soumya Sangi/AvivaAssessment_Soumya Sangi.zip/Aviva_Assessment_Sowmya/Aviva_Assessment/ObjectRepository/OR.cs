﻿using Aviva_Assessment.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Aviva_Assessment.ObjectRepository
{
    class OR
    {
        public OR()
        {
            PageFactory.InitElements(BaseDriver.driver, this);
        }

        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement SearchBox { get; set; }
        public void enterText(string Text)
        {
            SearchBox.Clear();
            SearchBox.SendKeys(Text);
         }
        //FindsBy(How = How.Name, Using = "btnK"), 
        [FindsBy(How = How.XPath, Using = "//input[@value='Google Search']")]
        public IWebElement SearchBtn { get; set; }
        public void click()
        {
            SearchBtn.Click();
        }
       
        [FindsBy(How = How.Id, Using = "resultStats")]
        public IWebElement ResultsString { get; set; }

        public int NumberOfLinks(string Keyword)
        {
            IList<IWebElement> Ls = BaseDriver.driver.FindElements(By.XPath("//a[contains(text(),'" + Keyword + "')]"));
            return Ls.Count;
        }
        public String LinkText(string Keyword, int linkIndex)
        {
            IList<IWebElement> Ls = BaseDriver.driver.FindElements(By.XPath("//a[contains(text(),'" + Keyword + "')]"));
            var Ltext= Ls.ElementAt((linkIndex)-1).Text;
            return Ltext;
        }





    }

}
