﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using WebTestAssignment.PageObjects;
using WebTestAssignment.Utils;

namespace WebTestAssignment.StepDefinitions
{

    [Binding]
    public class GoogleSearchSteps : BaseFunc
    {
       static ScreenShot ss;
        GoogleSearchPage srchPg;
        GoogleSearchResultsPage resultsPg;

        [BeforeScenario]
        public void SetUp()
        {
            //invoke the configured browser
            setDriver();           

        }

        [Given(@"user is on Google home page")]
        public void LandOnGoogleHomePg()
        {
            srchPg = new GoogleSearchPage();
            srchPg.NavigateToGoogleHomePg();
        }
        
        [When(@"user does search with a (.*)")]
        public void DoASearch(string searchString)
        {
            //this code section will enter a text in Google search box and clicks on submit
            srchPg = new GoogleSearchPage();
            srchPg.PerformSearch(searchString);
        }
        
        [Then(@"user will count all the links that are displayed in the result")]
        public void CountAllTheLinksThatAreDisplayedInTheResult()
        {
            //this code section will count the total links that are displayed on results page
           
            resultsPg = new GoogleSearchResultsPage();
            int totalLinks = resultsPg.CountAllLinksFromResultsPg();
            Console.WriteLine(totalLinks);
        }        
        

        [Then(@"prints the link text of the link (.*) from the result")]
        public void ThenPrintsTheLinkTextOfTheLinkFromTheResult(int linkNumb)
        {
            //this code section will print the text of a given link from the results page
            resultsPg = new GoogleSearchResultsPage();
            string desiredLnkText = resultsPg.GetLnkTxtOfGivenLink(linkNumb);
        }

        [Then(@"user will verify atleast (.*) links that are displayed in the result")]
        public void VerifyMinimumLinksDisplayed(int linkNumb)
        {
            //this code will assert if minimum expected links are displayed or not
            resultsPg = new GoogleSearchResultsPage();
            int totalLinks = resultsPg.CountAllLinksFromResultsPg();
            Assert.Greater(totalLinks, linkNumb);
        }

        [Then(@"No matching results are displayed")]
        public void VerifyNoResultsAreDisplayed()
        {
            resultsPg = new GoogleSearchResultsPage();
            resultsPg.VerifyNoSearchResults();
        }

        [AfterScenario]
        public static void TearDown()
        {
            driver.Close();
            driver.Quit();
            driver = null;
        }

        [AfterStep]
        public static void CaptureScreenshot()
        {
            ss = new ScreenShot();
            ss.TakeScreenshot();
        }

    }
}
