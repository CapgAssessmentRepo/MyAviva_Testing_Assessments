﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebTestAssignment.Utils;

namespace WebTestAssignment.PageObjects
{
    public class GoogleSearchPage : BaseFunc
    {

        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement ipSearchBox { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement btnGoogleSearch { get; set; }

        public GoogleSearchPage()
        {
            PageFactory.InitElements(BaseFunc.driver, this);
        }

        public void PerformSearch(string keyword)
        {
            Thread.Sleep(2000);
            PopulateTextBox(ipSearchBox, keyword, "Google Search input box");           
            ClickElement(btnGoogleSearch, "Google Search button");           
        }
               

        public void NavigateToGoogleHomePg()
        {
            Console.WriteLine("Navigating to Goolge home page");
            driver.Navigate().GoToUrl("https://google.com");

        }


    }
}
