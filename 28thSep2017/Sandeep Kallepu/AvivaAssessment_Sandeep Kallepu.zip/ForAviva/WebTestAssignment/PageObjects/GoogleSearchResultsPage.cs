﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebTestAssignment.Utils;

namespace WebTestAssignment.PageObjects
{
    public class GoogleSearchResultsPage : BaseFunc
    {
        new IWebDriver driver = null;
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Aviva')]")]
        public IList<IWebElement> linksOnResultsPg { get; set; }

        [FindsBy(How = How.TagName, Using = "a")]
        public IList<IWebElement> allLinks_ResultsPg { get; set; }

        public GoogleSearchResultsPage()
        {
            PageFactory.InitElements(BaseFunc.driver, this);
            this.driver = BaseFunc.driver;
        }

        //we can define any other web elements and required methods that make sense to results page
        public int CountAllLinksFromResultsPg()
        {
            int count = allLinks_ResultsPg.Count();
            return count;
        }

        public string GetLnkTxtOfGivenLink(int linkNum)
        {    
            String txt = linksOnResultsPg.ElementAt(linkNum-1).Text;
            Console.WriteLine("link text of "+linkNum+" link is "+ txt);
            return txt;
        }

        public void VerifyNoSearchResults()
        {
            IWebElement element = driver.FindElement(By.XPath("//li[contains(text(),'Make sure that all words are spelled correctly')]"));
            bool IsNoMatchingDoc = VerifyElementDisplay(element);
            if (IsNoMatchingDoc == true)
            {
                Console.WriteLine("No Search Results Displayed");
            }
            else {
                Console.WriteLine("verification failed, seems like you got some results");
            }
        }
    }
}
