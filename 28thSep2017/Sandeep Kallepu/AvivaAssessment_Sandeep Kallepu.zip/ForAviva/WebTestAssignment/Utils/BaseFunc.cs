﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecRun.Common.Logging;

namespace WebTestAssignment.Utils
{
    public class BaseFunc
    {
        public static IWebDriver driver;


        public static void setDriver()
        {
            String browserName = ConfigurationManager.AppSettings["browserType"];
            if (browserName.ToLower() == "chrome")
            {
                driver = new ChromeDriver();
            }else if (browserName.ToLower() == "ie")
            {
                driver = new InternetExplorerDriver();
            }

            driver.Manage().Window.Maximize();
        }
        

        public static void NavigateToURL(string URL)
        {
            Console.WriteLine("Navigating to the URL - " + URL);
            driver.Navigate().GoToUrl(URL);
        }

        public static void PopulateTextBox(IWebElement element, string Text, string elementName)
        {
            element.Clear();
            element.SendKeys(Text);
            Log.Info("Populated '" + elementName + "' with text - " + Text);
            Console.WriteLine("Populated '" + elementName + "' with text - " + Text);
            
        }

        public static void ClickElement(IWebElement element, string elementName)
        {
            element.Click();
            Log.Info("Clicked on '" + elementName + "'");
            Console.WriteLine("Clicked on '" + elementName + "'");
        }

        public static void CleanUp()
        {
            driver.Close();
            driver.Quit();
            driver = null;
        }
      
	public static void SelectByValue(IWebElement element, string Text, string elementName)
        {
            SelectElement select = new SelectElement(element);
            select.SelectByValue(Text);
            Console.WriteLine("Selected the value '" +Text+"' from the dropdown '"+ elementName + "'");

        }

        public static void SelectByIndex(IWebElement element, int index, string elementName)
        {
            SelectElement oSelect = new SelectElement(element);
            oSelect.SelectByIndex(index);
            Console.WriteLine("Selected option '" + (index + 1) + "' from the dropdown '" + elementName + "'");
        }

        public static bool VerifyElementDisplay(IWebElement element)
        {
            bool IsElementDisplayed=false;

           try
            {
                if (element.Displayed)
                {
                    IsElementDisplayed = true;
                }
            }
            catch (NoSuchElementException)
            {
                return IsElementDisplayed;                
            }

            return IsElementDisplayed;
        }

      
    }
}
