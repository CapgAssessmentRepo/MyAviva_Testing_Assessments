﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebTestAssignment.Utils
{
    class ScreenShot : BaseFunc
    {
        public void ScreenShots()
        {
            PageFactory.InitElements(BaseFunc.driver, this);
        }

        public object SeleniumImageFormat { get; private set; }
        public void TakeScreenshot()
        {
            ITakesScreenshot takesScreenshot = (ITakesScreenshot)driver;
            if (takesScreenshot != null)
            {
                var screenshot = takesScreenshot.GetScreenshot();
                var tempFileName = Path.Combine(Directory.GetCurrentDirectory(), Path.GetFileNameWithoutExtension(Path.GetTempFileName())) + ".jpg";
                screenshot.SaveAsFile(tempFileName, ScreenshotImageFormat.Jpeg);
                Console.WriteLine($"SCREENSHOT[ file:///{tempFileName} ]SCREENSHOT");
            }
        }
    }
}
