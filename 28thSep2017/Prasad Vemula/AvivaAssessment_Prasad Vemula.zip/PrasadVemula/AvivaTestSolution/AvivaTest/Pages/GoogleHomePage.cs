﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using AvivaTest.Utility;

namespace AvivaTest.Pages
{
    class GoogleHomePage:BaseTest
    {
        public GoogleHomePage()
        {
            PageFactory.InitElements(BaseTest.driver, this);
        }

        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement SearchBox { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement GoogleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "hplogo")]
        public IWebElement GoogleLogo { get; set; }        

        public void searchWithText(string sText)
        {
            EnterText(SearchBox, sText);
        }
        public void ClickonSearch()
        {
            ClickElement(GoogleSearch);
        }
        public Boolean IsLogoDisplayed()
        {
            return IsElementPresent(GoogleLogo);
        }
        

    }
}
