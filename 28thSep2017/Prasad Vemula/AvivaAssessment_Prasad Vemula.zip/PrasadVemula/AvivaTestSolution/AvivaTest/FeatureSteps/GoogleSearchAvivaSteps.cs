﻿using System;
using TechTalk.SpecFlow;
using AvivaTest.Utility;
using AvivaTest.Pages;
using NUnit.Framework;

namespace AvivaTest.FeatureSteps
{
    [Binding]
    public class GoogleSearchAvivaSteps:BaseTest
    {
        GoogleHomePage ghp;
        ResultsPage rp;
        ScreenShots st;
        [BeforeScenario]
        public void Setup()
        {
            initializeDriver("Chrome");
            ghp = new GoogleHomePage();
            rp = new Pages.ResultsPage();
            st = new ScreenShots();
        }
        [Given(@"User launches the google home page url")]
        public void GivenUserLaunchesTheGoogleHomePageUrl()
        {
            ghp.NavigateToURL("https://google.com");
        }
        
        [When(@"inputs search keyword as ""(.*)""")]
        public void WhenInputsSearchKeywordAs(string p0)
        {
            ghp.searchWithText(p0);
        }
        
        [When(@"clicks on the search submit button")]
        public void WhenClicksOnTheSearchSubmitButton()
        {
            ghp.ClickonSearch();
        }
        
        [Then(@"prints the link text of (.*)th link")]
        public void ThenPrintsTheLinkTextOfThLink(int p0)
        {
            string fifthText = rp.LinkText(p0);
            Console.WriteLine("Fifth Link Text : " + fifthText);

        }
        
        [Then(@"Total Returned links count should be (.*)")]
        public void ThenTotalReturnedLinksCountShouldBe(int p0)
        {
            Assert.AreEqual(rp.getLinksCount(), p0);
        }
        
        [Then(@"Use verify WindowTitle is ""(.*)""")]
        public void ThenUseVerifyWindowTitleIs(string p0)
        {
            string title = DriverTitle();
            Assert.AreNotEqual(title, p0);
            Console.WriteLine("Browser Title :"+title);
        }
        [AfterScenario]
        public void TearDown()
        {
            CloseBrowser();
        }
        [AfterStep()]
        public void TakingScreenShot()
        {
            st.TakeScreenshot();
        }

    }
}
