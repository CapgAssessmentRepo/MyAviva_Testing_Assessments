﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AvivaTest.Utility
{
    public class BaseTest
    {
        public static IWebDriver driver;


        public void initializeDriver(string driverType)
        {
            if (driverType.Equals("Chrome"))
                driver = new ChromeDriver();
                driver.Manage().Window.Maximize();
        }
        public void CloseBrowser()
        {
            driver.Close();
            driver.Quit();
        }

        public void NavigateToURL(string sURL)
        {
            driver.Navigate().GoToUrl(sURL);
        }
        public void EnterText(IWebElement webElement, string Text)
        {
            webElement.SendKeys(Text);
        }
        public void ClickElement(IWebElement webElement)
        {

            webElement.Click();
        }

        public Boolean IsElementPresent(IWebElement webElement)
        {
            return webElement.Displayed;
        }
        public string ElementText(IWebElement webElement)
        {
            return webElement.Text;

        }
        public string DriverTitle()
        {
            return driver.Title;
        }

    }
}
