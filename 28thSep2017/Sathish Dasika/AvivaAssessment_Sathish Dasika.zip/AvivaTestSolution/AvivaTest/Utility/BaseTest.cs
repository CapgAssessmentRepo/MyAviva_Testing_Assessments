﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace AvivaAssessmentSatish
{
    public class BaseTest
    {
        public static IWebDriver driver;


        public void initializeDriver(string driverType)
        {
            if (driverType.Equals("Chrome"))
                driver = new ChromeDriver();
                driver.Manage().Window.Maximize();
           
        }
        public void CloseBrowser()
        {
            driver.Close();
            driver.Quit();
        }

        public void NavigateToURL(string sURL)
        {
            driver.Navigate().GoToUrl(sURL);
        }
        public void EnterText(IWebElement WebEmelent, string Text)
        {
            WebEmelent.SendKeys(Text);
        }
        public void ClickElement(IWebElement WebEmelent)
        {
          
            WebEmelent.Click();
        }

        public Boolean IsElementPresent(IWebElement WebEmelent)
        {
            return WebEmelent.Displayed;
        }
      
    }
}
