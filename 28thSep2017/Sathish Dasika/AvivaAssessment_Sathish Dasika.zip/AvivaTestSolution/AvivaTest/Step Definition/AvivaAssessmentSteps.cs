﻿using AvivaAssessmentSatish;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace AvivaAssessmentSatish.Step_Definition
{
    [Binding]
    public class AvivaAssessmentSteps : BaseTest
    {
        GoogleHomePage ghp;
        ScreenShots st;
        SearchResultsPage srp;

        [BeforeScenario]
        public void Setup()
        {
            initializeDriver("Chrome");
            ghp = new GoogleHomePage();
            st = new ScreenShots();
            srp = new SearchResultsPage();
        }

        [Given(@"User should be navigated to the Google Home Page")]
        public void GivenUserShouldBeNavigatedToTheGoogleHomePage()
        {
            ghp.NavigateToURL("http://google.co.in");
        }

        [Given(@"User should be able to validate that the Google Home Page is launched successfully")]
        public void GivenUserShouldBeAbleToValidateThatTheGoogleHomePageIsLaunchedSuccessfully()
        {
            Assert.AreEqual(ghp.IsLogoDisplayed(), true);
            Console.WriteLine("Google Launch validated");
        }


        [When(@"User enters the search string (.*) in the search field and clicks on search button")]
        public void WhenUserEntersTheSearchStringInTheSearchFieldAndClicksOnSearchButton(string searchText)
        {
            ghp.searchWithText(searchText);
            ghp.ClickonSearch();
        }

        [Then(@"User should be navigated to the first search results page and fifth link text should be displayed")]
        public void ThenUserShouldBeNavigatedToTheFirstSearchResultsPageAndFifthLinkTextShouldBeDisplayed()
        {
            Assert.AreEqual(srp.fetchLinksCount(srp.Links), 15);
            int noOfavivaLinks = srp.fetchLinksCount(srp.Links);
            Console.WriteLine("The number of search links with aviva text are " + noOfavivaLinks);
            string fifthLinkText = srp.fetchLinkText(4, srp.Links);
            Console.WriteLine("The fifth search link with aviva text is: " + fifthLinkText);
            Console.WriteLine("Positive Test Scenario is validated successfully");
        }

        [Then(@"User should not be displayed with the aviva search links on the results page")]
        public void ThenUserShouldNotBeDisplayedWithTheAvivaSearchLinksOnTheResultsPage()
        {

            int noOfOtherLinks = srp.fetchLinksCount(srp.Links1);
            Console.WriteLine("the number of links with india search doesnot match the aviva search: " + noOfOtherLinks);
            string otherSearchText = srp.fetchLinkText(4, srp.Links1);
            Console.WriteLine("The fifth search link with other than aviva text is: " + otherSearchText);
            Console.WriteLine("Neagtive test scenario is validated successfully");
        }

        [AfterScenario]
        public void TearDown()
        {
            CloseBrowser();
        }

        [AfterStep()]
        public void TakeScreenshots()
        {
            st.TakeScreenshot();
        }

    }
}




