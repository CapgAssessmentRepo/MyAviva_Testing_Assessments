﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvivaAssessmentSatish
{
    class SearchResultsPage : BaseTest
    {
        public SearchResultsPage()
        {
            PageFactory.InitElements(BaseTest.driver, this);
        }

        //Search Results Page Objects

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Aviva')]")]
        public IList<IWebElement> Links { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'India')]")]
        public IList<IWebElement> Links1 { get; set; }

        //Search Results Page Methods
        public int fetchLinksCount(IList<IWebElement> IWebElement)
        {
            return IWebElement.Count;
        }
        public String fetchLinkText(int i, IList<IWebElement> IWebElement)
        {
            String LinkText = IWebElement.ElementAt(i).Text;
            return LinkText;
        }
    }

}


