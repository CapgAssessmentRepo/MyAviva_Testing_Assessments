﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvivaAssessmentSatish
{
    class GoogleHomePage : BaseTest
    {
        public GoogleHomePage()
        {
            PageFactory.InitElements(BaseTest.driver, this);
        }

        // Google Home Page Objects

        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement SearchBox { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement GoogleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "hplogo")]
        public IWebElement GoogleLogo { get; set; }

       //Google Home Page Methods
        public void searchWithText(string sText)
        {
            EnterText(SearchBox, sText);
        }
        public void ClickonSearch()
        {
            ClickElement(GoogleSearch);
        }

        public Boolean IsLogoDisplayed()
        {
            return IsElementPresent(GoogleLogo);
        }


    }
}











