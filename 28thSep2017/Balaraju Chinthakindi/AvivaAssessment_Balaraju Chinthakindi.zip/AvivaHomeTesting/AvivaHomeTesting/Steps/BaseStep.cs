﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace AvivaHomeTesting.Steps
{
    public class BaseStep
    {
        private static IWebDriver _driver;

/// <summary>
/// Initializes driver with given browser instance and maximizes the window
/// </summary>
/// <param name="sBrowserName"></param>

        public void InitializeDriver(string sBrowserName)
        {
            // Chrome
            if (sBrowserName.Equals("Chrome"))
            {
                _driver = new ChromeDriver();
                _driver.Manage().Window.Maximize();
            }
            //IE
            if (sBrowserName.Equals("IE"))
            {
                _driver = new InternetExplorerDriver();
                _driver.Manage().Window.Maximize();
            }
            //Firefox
            if (sBrowserName.Equals("Firefox"))
            {
                _driver = new FirefoxDriver();
                _driver.Manage().Window.Maximize();
            }
        }

        /// <summary>
        /// setter and getter for _driver instance
        /// </summary>
        public IWebDriver Driver { get { return _driver; } set { Driver = _driver; } }


        /// <summary>
        /// Navigates to given URL in opened browser window
        /// </summary>
        /// <param name="sURL"></param>
        public void NavigateToURL(string sURL)
        {
            _driver.Navigate().GoToUrl(sURL);
        }

        /// <summary>
        /// Takes a screenshot after each step and embeds in result report
        /// </summary>
        [AfterStep]        
        public void MakeScreenshotAfterStep()
        {
            var takesScreenshot = _driver  as ITakesScreenshot;
            if (takesScreenshot != null)
            {
                var screenshot = takesScreenshot.GetScreenshot();
                var tempFileName = Path.Combine(Directory.GetCurrentDirectory()+"\\Screenshots", Path.GetFileNameWithoutExtension(Path.GetTempFileName())) + ".jpg";
                screenshot.SaveAsFile(tempFileName, ScreenshotImageFormat.Jpeg);

                Console.WriteLine($"SCREENSHOT[ file:///{tempFileName} ]SCREENSHOT");
            }
        }


        /// <summary>
        /// Closes the driver instance
        /// </summary>
        [AfterScenario]
        public void CleanUp()
        {            
            _driver.Quit();
        }

        
    }
}


    