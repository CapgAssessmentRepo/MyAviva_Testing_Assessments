﻿using AvivaHomeTesting.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace AvivaHomeTesting.Steps
{
    [Binding]
    public sealed class GoogleSteps : BaseStep
    {
        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef

        GooglePage Page_Google;

        [Given(@"Launch browser ""(.*)""")]
        public void GivenLaunchBrowser(string p0)
        {
            InitializeDriver(p0);
            Page_Google = new GooglePage();
        }

        [Given(@"Navigate to ""(.*)""")]
        public void GivenNavigateTo(string p0)
        {
            NavigateToURL(p0);
        }

        [When(@"Search with keyword ""(.*)""")]
        public void WhenSearchWithKeyword(string p0)
        {
            Page_Google.SearchWithText(p0);
            
        }

        [Then(@"Results should be displayed")]
        public void ThenResultsShouldBeDisplayed()
        {
            Assert.IsTrue(Page_Google.lnklResults.Displayed);
        }

        [Then(@"Total returned links count with text ""(.*)"" should be (.*)")]
        public void ThenTotalReturnedLinksCountWithTextShouldBe(string p0, int p1)
        {
            Assert.AreEqual(p1, Page_Google.GetTotalRelatedLinks(p0));
        }

        [Then(@"Display text of the (.*)th link from the result")]
        public void ThenDisplayTextOfTheThLinkFromTheResult(int p0)
        {
            Console.WriteLine("The " + p0 + " th Link Name:");
            Console.WriteLine(Page_Google.GetLinkTextOfLink(p0 - 1));
            Assert.AreNotEqual("Nothing", Page_Google.GetLinkTextOfLink(p0 - 1));
        }



    }
}
