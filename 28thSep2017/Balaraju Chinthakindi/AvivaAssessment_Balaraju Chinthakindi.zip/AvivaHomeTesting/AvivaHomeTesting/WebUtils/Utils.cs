﻿using AvivaHomeTesting.Steps;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AvivaHomeTesting.WebUtils
{
    public static class Utils
    {
        public static void WaitForElementPresent(this IWebElement webelement, IWebDriver Driver, int iTimeOut)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(iTimeOut));
            //wait.Until(ExpectedConditions.ElementIsVisible(webelement.GetType().GetProperties().);

            int iSec = 0;
            while(true)
            {
                try
                {
                    if (webelement.Displayed)
                    {
                        Console.WriteLine("Element Present..");
                        break;                        
                    }
                    else
                    {
                        if (iSec != iTimeOut)
                        {
                            Thread.Sleep(2);
                            iSec = iSec + 2;
                        }

                    }
                } catch (Exception e)
                {
                    Console.WriteLine("Waiting for Element to Present...");
                }
            }
        }

        public static void EnterText(this IWebElement webElement, string sText)
        {
            webElement.SendKeys(sText);
        }
        public static void ClickElement(this IWebElement webElement)
        {
            webElement.Click();
        }
        public static void SelectDropDown_Text(this SelectElement webElement, string sVisibleText)
        {
            webElement.SelectByText(sVisibleText);
        }

        public static void SelectDropDown_Value(this SelectElement webElement, string sValue)
        {
            webElement.SelectByValue(sValue);
        }

        public static void SelectDropDown_Index(this SelectElement webElement, int iIndex)
        {
            webElement.SelectByIndex(iIndex);
        }

        public static void SelectDropDown_DeSelectAll(this SelectElement webElement)
        {
            webElement.DeselectAll();           
        }

        public static void CheckCheckBox(this IWebElement webElement, string sValue)
        {
            if(webElement.GetAttribute("value").Equals(sValue))
            {
                if (!webElement.GetAttribute("checked").Equals("true"))
                    webElement.Click();
            }
        }

        public static void UnCheckCheckBox(this IWebElement webElement, string sValue)
        {
            if (webElement.GetAttribute("value").Equals(sValue))
            {
                if (webElement.GetAttribute("checked").Equals("true"))
                    webElement.Click();
            }
        }
    }
}
