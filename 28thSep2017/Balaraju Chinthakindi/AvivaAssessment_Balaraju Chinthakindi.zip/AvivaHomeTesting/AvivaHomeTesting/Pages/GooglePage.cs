﻿using AvivaHomeTesting.Steps;
using AvivaHomeTesting.WebUtils;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvivaHomeTesting.Pages
{
    public class GooglePage : BaseStep
    {
        public GooglePage()
        {
            PageFactory.InitElements(Driver, this);           

        }


        [FindsBy(How = How.Name, Using = "q")]
        public IWebElement TxtSearchBox { get; set; }

        [FindsBy(How = How.Id, Using = "hplogo")]
        public IWebElement ImgGoogleLogo { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement BtnGoogleSearch { get; set; }       

        [FindsBy(How = How.XPath, Using = ".//h3/a")]
        public IList<IWebElement> LnkAviva { get; set; }

        [FindsBy(How = How.Id, Using = "resultStats")]
        public IWebElement lnklResults { get; set; }

        public void SearchWithText(string sKeyword)
        {

            TxtSearchBox.WaitForElementPresent(Driver, 10);
            TxtSearchBox.EnterText(sKeyword);
            TxtSearchBox.EnterText(Keys.Tab);
            BtnGoogleSearch.Submit();
        }

        public int  GetTotalRelatedLinks(string sKeyword)
        {
            return LnkAviva.Count;
        }

        public string GetLinkTextOfLink(int iIndex)
        {
            int i = 0;
            foreach (IWebElement element in LnkAviva)
            {
                if (i == iIndex )
                {
                    return element.GetAttribute("text");                    
                }
                i++;
            }
            return "Nothing";
        }

    }
}
